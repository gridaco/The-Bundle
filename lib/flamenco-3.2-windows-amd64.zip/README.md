# Flamenco 3

This repository contains the sources for Flamenco 3. The Manager, Worker, and
Blender add-on sources are all combined in this one repository.

The documentation is available on https://flamenco.blender.org/, including
instructions on how to set up a development environment & build Flamenco for the
first time.

To access the documentation offline, go to the `web/project-website/content`
directory here in the source files.


## License

Flamenco is licensed under the GPLv3+ license.
